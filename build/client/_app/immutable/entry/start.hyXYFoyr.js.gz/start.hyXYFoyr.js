import{b as a}from"../chunks/entry.CyY1ZB4d.js";export{a as start};
