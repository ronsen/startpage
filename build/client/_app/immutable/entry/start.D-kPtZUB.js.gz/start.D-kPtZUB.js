import{b as a}from"../chunks/entry.DBFfIOUl.js";export{a as start};
