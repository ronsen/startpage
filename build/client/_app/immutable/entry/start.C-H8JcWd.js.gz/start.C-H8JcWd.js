import{b as a}from"../chunks/entry.Dh2-vdD5.js";export{a as start};
