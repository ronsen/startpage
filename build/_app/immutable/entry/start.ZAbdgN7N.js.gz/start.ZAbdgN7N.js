import{a as t}from"../chunks/entry.eGbv3zcc.js";export{t as start};
