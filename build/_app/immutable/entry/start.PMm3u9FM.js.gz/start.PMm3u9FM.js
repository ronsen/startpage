import{a as t}from"../chunks/entry.oKoSSx1r.js";export{t as start};
