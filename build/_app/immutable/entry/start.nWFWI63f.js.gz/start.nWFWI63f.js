import{a as t}from"../chunks/entry.6yRvr519.js";export{t as start};
