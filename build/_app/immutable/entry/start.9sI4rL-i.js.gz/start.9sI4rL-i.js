import{a as t}from"../chunks/entry.t11hbcqc.js";export{t as start};
